# CTD Strategies — website starter

A responsive English/Russian community strategy site for Cameraman Tower Defense, designed to work on iPhone and be hosted with GitHub Pages.

## Included
- Responsive landing page and strategy cards
- Search by strategy title and difficulty filters: Easy, Medium, Insane, Nightmare
- Strategy detail view with wave plan, proof notes and images
- Submission form requiring a name, difficulty, description, wave-by-wave plan, at least one image, and proof notes
- Report form with “Strategy doesn't work” and “Inappropriate content” reasons
- English/Russian toggle
- Firebase Auth (Google + email/password), Firestore, and Storage integration hooks
- Demo strategies are explicitly marked as examples/placeholders, not verified builds

## Important before public launch
The website currently opens in demo mode. Demo sign-in is only a local preview and is **not secure authentication**. Posts and reports are only saved in the current browser unless Firebase is configured. Do not publish it as a real community database until Firebase is connected and its security rules are set.

## Publish from an iPhone using GitHub
1. Sign in at https://github.com/ and create a new **public** repository named `ctd-strategies` (or any name).
2. Upload `index.html`, `README.md`, and the entire `assets` folder from this ZIP. On GitHub, use **Add file → Upload files**. Keep the asset filenames unchanged.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
5. Wait for GitHub Pages to finish. Your site URL will look like `https://YOUR-USERNAME.github.io/ctd-strategies/`.

## Enable real Google/email accounts and shared posts (Firebase)
1. Open https://console.firebase.google.com/ and create a project.
2. Add a Web app (`</>`), then copy its Firebase config object.
3. In `index.html`, find this line near the top of the script:
   `const firebaseConfig = null;`
   Replace `null` with your config object, e.g.
   `const firebaseConfig = { apiKey: "...", authDomain: "...", projectId: "...", storageBucket: "...", messagingSenderId: "...", appId: "..." };`
4. In Firebase Console → **Authentication → Sign-in method**, enable **Email/Password** and **Google**. Add your GitHub Pages domain (e.g. `YOUR-USERNAME.github.io`) under **Authentication → Settings → Authorized domains**.
5. Create a **Cloud Firestore** database and **Storage** bucket.
6. In Firestore, create these collections as the app uses them: `strategies` and `reports` (they can be created automatically by the first write).
7. Configure secure Firestore and Storage rules before inviting users. The simple starter app does not include moderation/admin roles or anti-spam controls; rules must be tightened before launch.

### Suggested starter Firestore rules (review and adapt before launch)
These rules allow signed-in users to create strategy documents and reports. Reads are public. They do not enforce content moderation or ownership on updates, so for a public launch you should improve them (e.g. permit create only, validate field sizes, require author UID, add admin review, rate limits).

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /strategies/{id} {
      allow read: if true;
      allow create: if request.auth != null;
      allow update, delete: if false;
    }
    match /reports/{id} {
      allow create: if request.auth != null;
      allow read, update, delete: if false;
    }
  }
}
```

### Suggested starter Storage rules (review and adapt before launch)
```text
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /strategies/{strategyId}/{fileName} {
      allow read: if true;
      allow write: if request.auth != null
                   && request.resource.size < 4 * 1024 * 1024
                   && request.resource.contentType.matches('image/.*');
    }
  }
}
```

## Notes
- GitHub Pages is static hosting, so it cannot securely keep passwords or act as a database by itself. Firebase supplies the auth and shared database/storage.
- The visitor count shown in the demo is a placeholder, not live analytics.
- The three included strategy cards are sample outlines to demonstrate layout. They are clearly labelled as samples and are not guaranteed to work in-game.
- The report button submits to Firebase only after Firebase is configured; in demo mode it stores a report in this browser.
